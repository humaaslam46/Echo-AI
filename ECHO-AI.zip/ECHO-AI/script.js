// Footer Year Auto Update
document.getElementById('year').textContent = new Date().getFullYear();
